package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText kullaniciadi, sifre;
    TextView textView;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        kullaniciadi = findViewById(R.id.editTextText);
        sifre = findViewById(R.id.editTextText2);
        textView = findViewById(R.id.textView2);

        // Kaydol yazısına tıklandığında MainActivity2'ye gider
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);
            }
        });
    }

    public void btngrs(View view) {
        String kadi = kullaniciadi.getText().toString();
        String Ksif = sifre.getText().toString();

        if (Ksif.matches("") || kadi.matches("")) {
            Toast.makeText(this, "KULLANICI ADI VE ŞİFRE GİRMELİSİNİZ", Toast.LENGTH_LONG).show();
        } else {
            sharedPreferences = this.getSharedPreferences("com.example.myapplication", MODE_PRIVATE);
            String gelenSifre = sharedPreferences.getString(kadi, "??YOK");

            if (gelenSifre.matches(Ksif)) {
                Intent intent = new Intent(MainActivity.this, MainActivity3.class);
                intent.putExtra("kullanici", kadi);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Hatalı kullanıcı adı veya şifre", Toast.LENGTH_LONG).show();
            }
        }
    }
}