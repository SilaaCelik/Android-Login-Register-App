package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {
    EditText editTextKadi, editTextSifre;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        editTextKadi = findViewById(R.id.editTextText3);
        editTextSifre = findViewById(R.id.editTextText4);
    }

    public void btnnkayit(View view) {
        String kadi = editTextKadi.getText().toString();
        String ksif = editTextSifre.getText().toString();

        if (!kadi.matches("") && !ksif.matches("")) {
            sharedPreferences = this.getSharedPreferences("com.example.myapplication", MODE_PRIVATE);
            sharedPreferences.edit().putString(kadi, ksif).apply();

            Toast.makeText(MainActivity2.this, "Başarıyla kayıt olundu", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(MainActivity2.this, MainActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(MainActivity2.this, "KULLANICI ADI VEYA ŞİFRE HATALI", Toast.LENGTH_SHORT).show();
        }
    }
}